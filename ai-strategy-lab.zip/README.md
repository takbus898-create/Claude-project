# AI Strategy Lab — Live Setup

This runs for real, on its own, every trading day: a GitHub Actions job pulls
real closing prices from Alpaca, runs all 5 strategies, and commits the
result — and your GitHub Pages site shows it live. No server for you to run,
no cost.

## 1. Get free Alpaca API keys (2 minutes)

1. Go to **alpaca.markets** and sign up for a free account.
2. Once logged in, make sure you're in **Paper Trading** mode (it's the
   default — look for "Paper" in the top bar).
3. Go to your dashboard → **API Keys** → generate a new key pair.
4. Copy the **API Key ID** and **Secret Key** somewhere safe — the secret is
   only shown once.

This is real market data (IEX feed), simulated money. When you're ready for
real money later, you create a *live* key pair on the same Alpaca account and
swap it in — the bot's code doesn't need to change.

## 2. Create the GitHub repo

1. Go to **github.com** → **New repository** → name it something like
   `ai-strategy-lab` → **Public** (required for free GitHub Pages) → Create.
2. Upload all the files from this project, keeping the folder structure:
   ```
   .github/workflows/daily-update.yml
   docs/index.html
   docs/data/state.json
   trading_bot.py
   ```
   Easiest way: on the repo page, click **Add file → Upload files**, drag
   everything in (GitHub preserves folder paths when you drag whole folders).

## 3. Add your Alpaca keys as repo secrets

1. In your repo: **Settings → Secrets and variables → Actions**.
2. **New repository secret** → name it `ALPACA_API_KEY`, paste your key ID.
3. **New repository secret** → name it `ALPACA_SECRET_KEY`, paste your secret.

## 4. Turn on GitHub Pages

1. **Settings → Pages**.
2. Under "Build and deployment", set **Source: Deploy from a branch**.
3. Branch: **main**, folder: **/docs** → Save.
4. GitHub gives you a URL like `https://yourusername.github.io/ai-strategy-lab/`
   — that's your live dashboard link.

## 5. Test it right now (don't wait for the schedule)

1. Go to the **Actions** tab in your repo.
2. Click **Daily Strategy Lab Update** on the left.
3. Click **Run workflow** (the manual trigger button) → **Run workflow**.
4. Wait ~30 seconds, refresh — you should see a green checkmark.
5. Open your GitHub Pages URL — if today was a trading day, you'll see a new
   day added to the chart and trade log.

After this, it just runs itself: every weekday at 4:30pm ET, the bot pulls
the real close, updates the trades, and your dashboard reflects it — no
check-ins needed.

## What each file does

- **`trading_bot.py`** — the actual strategy logic (same 5 methods from the
  chat version). Pulls the latest real close from Alpaca, decides buys/sells
  per strategy, updates `docs/data/state.json`.
- **`.github/workflows/daily-update.yml`** — the free scheduler. Runs the bot
  on GitHub's servers every weekday after market close, then commits the
  updated file back to the repo.
- **`docs/index.html`** — the dashboard. Fetches `data/state.json` and
  renders it. No build step, no dependencies — just open it.
- **`docs/data/state.json`** — the data file itself, seeded with the 22 real
  trading days already run in this chat (Sep 2 – Oct 2, 2026), so the live
  version continues exactly where this conversation left off.

## Sanity checks if something doesn't update

- **Actions tab shows a red X:** click into the run, the log will usually say
  "ALPACA_API_KEY / ALPACA_SECRET_KEY not set" (secret name typo) or an
  Alpaca auth error (bad key).
- **Dashboard shows old data:** GitHub Pages can take 1–2 minutes to
  redeploy after a commit; hard-refresh the page.
- **No bars returned for a ticker:** happens if you run it on a day the
  market was closed (weekend/holiday) — the bot will just skip that run.
