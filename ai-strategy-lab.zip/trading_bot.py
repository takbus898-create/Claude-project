#!/usr/bin/env python3
"""
Daily AI Strategy Lab bot.
Pulls the latest real daily close for each tracked stock from Alpaca's
market data API (free, works with a paper-trading account), runs all
5 strategies against the new price, and appends the result to data/state.json.

Required environment variables (set as GitHub Actions secrets):
  ALPACA_API_KEY
  ALPACA_SECRET_KEY
"""
import json
import os
import sys
from datetime import datetime, timezone
import urllib.request

STATE_PATH = os.path.join(os.path.dirname(__file__), "docs", "data", "state.json")
TICKERS = ["JPM", "OMC", "HAS", "NVDA", "XOM"]

ALPACA_KEY = os.environ.get("ALPACA_API_KEY")
ALPACA_SECRET = os.environ.get("ALPACA_SECRET_KEY")
DATA_URL = "https://data.alpaca.markets/v2/stocks/bars?symbols={}&timeframe=1Day&limit=1&feed=iex".format(
    ",".join(TICKERS)
)


def fetch_latest_closes():
    if not ALPACA_KEY or not ALPACA_SECRET:
        print("ERROR: ALPACA_API_KEY / ALPACA_SECRET_KEY not set.", file=sys.stderr)
        sys.exit(1)
    req = urllib.request.Request(
        DATA_URL,
        headers={
            "APCA-API-KEY-ID": ALPACA_KEY,
            "APCA-API-SECRET-KEY": ALPACA_SECRET,
        },
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        payload = json.loads(resp.read())
    bars = payload.get("bars", {})
    closes, bar_date = {}, None
    for t in TICKERS:
        series = bars.get(t, [])
        if not series:
            print(f"WARNING: no bar returned for {t}", file=sys.stderr)
            continue
        latest = series[-1]
        closes[t] = latest["c"]
        bar_date = latest["t"][:10]  # YYYY-MM-DD
    return closes, bar_date


def ma(values, n):
    window = values[-n:]
    return sum(window) / len(window)


def run_strategies_for_new_day(state, closes, date_label):
    for t in TICKERS:
        state["prices"][t].append(closes[t])
    state["dates"].append(date_label)
    day = len(state["dates"]) - 1

    for strat in state["strategies"]:
        sid = strat["id"]
        ai = state["ais"][sid]

        def buy(ticker, price, frac, reason):
            spend = min(ai["cash"] * frac, ai["cash"])
            if spend < 20:
                return
            qty = int(spend // price)
            if qty < 1:
                return
            ai["cash"] -= qty * price
            ai["holdings"][ticker] = {"qty": qty, "entryPrice": price, "entryDay": day}
            ai["trades"].append({
                "day": day, "date": date_label, "ai": strat["name"], "action": "BUY",
                "t": ticker, "qty": qty, "price": price, "reason": reason,
            })

        def sell(ticker, price, reason):
            h = ai["holdings"].get(ticker)
            if not h:
                return
            pl = (price - h["entryPrice"]) * h["qty"]
            ai["cash"] += h["qty"] * price
            ai["trades"].append({
                "day": day, "date": date_label, "ai": strat["name"], "action": "SELL",
                "t": ticker, "qty": h["qty"], "price": price, "reason": reason, "pl": pl,
            })
            if pl >= 0:
                ai["wins"] += 1
            else:
                ai["losses"] += 1
            del ai["holdings"][ticker]

        for t in TICKERS:
            hist = state["prices"][t]
            price = hist[-1]
            holding = ai["holdings"].get(t)

            if sid == "momentum":
                if len(hist) < 6:
                    continue
                m5 = ma(hist[:-1], 5)
                if not holding and price > m5 * 1.01:
                    buy(t, price, 0.18, "breakout > MA5")
                elif holding and price < m5 * 0.99:
                    sell(t, price, "broke below MA5")

            elif sid == "meanrev":
                if len(hist) < 11:
                    continue
                m10 = ma(hist[:-1], 10)
                if not holding and price < m10 * 0.95:
                    buy(t, price, 0.18, "5%+ below MA10")
                elif holding and price >= m10 * 0.995:
                    sell(t, price, "reverted to MA10")

            elif sid == "volbreak":
                if len(hist) < 2:
                    continue
                chg = (price - hist[-2]) / hist[-2]
                if not holding and chg > 0.025:
                    buy(t, price, 0.18, "daily jump +2.5%")
                elif holding:
                    held_days = day - holding["entryDay"]
                    if chg < -0.018:
                        sell(t, price, "sharp reversal")
                    elif held_days >= 5:
                        sell(t, price, "time stop (5d)")

            elif sid == "random":
                import random
                if not holding and random.random() < 0.15:
                    buy(t, price, 0.15, "random entry")
                elif holding and random.random() < 0.15:
                    sell(t, price, "random exit")

            elif sid == "rebalance":
                total = ai["cash"] + sum(
                    ai["holdings"][tt]["qty"] * state["prices"][tt][-1]
                    for tt in ai["holdings"]
                )
                target = total * 0.20
                current = holding["qty"] * price if holding else 0
                if current < target * 0.75:
                    frac = min(0.25, (target - current) / max(ai["cash"], 1))
                    buy(t, price, frac, "rebalance up")
                elif current > target * 1.25 and holding:
                    sell(t, price, "rebalance down")

        val = ai["cash"] + sum(
            ai["holdings"][tt]["qty"] * state["prices"][tt][-1] for tt in ai["holdings"]
        )
        ai["valueHistory"].append(round(val, 2))

    state["lastUpdated"] = date_label


def main():
    with open(STATE_PATH) as f:
        state = json.load(f)

    closes, bar_date = fetch_latest_closes()
    if len(closes) < len(TICKERS):
        print("Missing some tickers, aborting this run.", file=sys.stderr)
        sys.exit(1)

    if bar_date and state["dates"] and bar_date in state.get("rawDates", []):
        print("Already have data for", bar_date, "- skipping.")
        return

    label = datetime.fromisoformat(bar_date).strftime("%b %-d") if bar_date else datetime.now(timezone.utc).strftime("%b %-d")
    state.setdefault("rawDates", []).append(bar_date)

    run_strategies_for_new_day(state, closes, label)

    with open(STATE_PATH, "w") as f:
        json.dump(state, f, indent=2)

    print(f"Updated state.json with {label} close: {closes}")


if __name__ == "__main__":
    main()
